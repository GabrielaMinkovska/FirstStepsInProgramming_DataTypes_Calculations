﻿namespace FirstStepsInProgramming_DataTypes_Calculations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}